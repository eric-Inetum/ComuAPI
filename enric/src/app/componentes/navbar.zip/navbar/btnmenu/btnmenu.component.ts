import { Component } from '@angular/core';

@Component({
  selector: 'app-btnmenu',
  templateUrl: './btnmenu.component.html',
  styleUrls: ['./btnmenu.component.css']
})
export class BtnmenuComponent {

}
